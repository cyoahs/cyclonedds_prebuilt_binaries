in_wheel = False
library_path = '/home/unitree/cyclonedds_wheel_build/install/cyclonedds-0.10.2/lib/libddsc.so'