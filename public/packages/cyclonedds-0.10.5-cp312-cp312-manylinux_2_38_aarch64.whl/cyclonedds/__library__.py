in_wheel = False
library_path = '/home/unitree/cyclonedds_wheel_build/install/cyclonedds-0.10.5/lib/libddsc.so'